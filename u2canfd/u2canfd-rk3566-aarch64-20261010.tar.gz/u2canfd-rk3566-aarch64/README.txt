在 RK3566 上解压本包，编辑 config/controller.ini，进入 u2canfd-rk3566-aarch64 目录，运行 ./run.sh。
修改配置后重启程序生效。也可运行 ./run.sh --config /path/to/controller.ini。
使用 ./dev_sn.sh 查看设备序列号。目标系统需要兼容打包的运行库。
本包不包含 glibc 和系统动态加载器；请核对设备系统版本与交叉编译工具链的 ABI。
